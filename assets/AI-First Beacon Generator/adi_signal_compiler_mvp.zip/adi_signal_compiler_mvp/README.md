# ADI Signal Compiler — MVP v0.1

Cloudflare Pages-ready static website.

## What it does

1. Ingests pasted website/page content.
2. Asks missing raw-material questions.
3. Generates AI-first root files:
   - robots.txt
   - sitemap.xml
   - llms.txt
   - ai.json
   - ai-entity.json
   - ai-relationships.json
   - ai-concepts.json
   - ai-intents.json
   - ai-faq.json
   - ai-offers.json
   - ai-proof.json
   - ai-trust.json
   - ai-evidence.json
   - ai-routes.json
   - ai-actions.json
   - ai-governance.json
   - ai-recommendation.json
   - ai-validation.json
   - ai-signals.json

## Deploy on Cloudflare Pages

Upload this folder to GitHub, then connect the repo to Cloudflare Pages.

- Build command: none
- Output directory: `/`

## Important

This is a deterministic MVP. It generates a structured AI-readable signal layer, but does not guarantee that every external AI crawler will consume every custom `ai-*.json` file.
