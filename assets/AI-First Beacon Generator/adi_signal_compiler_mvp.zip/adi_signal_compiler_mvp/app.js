const SIGNAL_FAMILIES = [
  "SITE","CRAWL","PAGE","ENT","REL","CON","INT","FAQ",
  "OFR","PRF","TRU","EVD","RTE","ACT","GOV","REC"
];

const SIGNAL_NAMES = {
  SITE:["site.id","site.name","site.url","site.publisher","site.language","site.country_scope","site.category","site.updated_at","site.schema_version","site.entrypoints"],
  CRAWL:["robots.exists","robots.allows_ai","sitemap.exists","sitemap.page_url","page.http_status","page.content_type","page.indexable","page.canonical","page.static_content","page.internal_links"],
  PAGE:["page.id","page.url","page.title","page.h1","page.meta_description","page.type","page.primary_entity","page.primary_intents","page.machine_files","page.last_modified"],
  ENT:["entity.id","entity.type","entity.name","entity.url","entity.description","entity.role","entity.same_as","entity.logo","entity.parent","entity.status"],
  REL:["relationship.id","relationship.subject","relationship.predicate","relationship.object","relationship.confidence","relationship.source","relationship.evidence_id","relationship.valid_from","relationship.direction","relationship.status"],
  CON:["concept.id","concept.name","concept.definition","concept.owner_entity","concept.page_url","concept.level_count","concept.level_ids","concept.level_names","concept.level_questions","concept.level_verdicts"],
  INT:["intent.id","intent.name","intent.question","intent.answer_target","intent.stage","intent.primary_entity","intent.related_offer","intent.priority","intent.language","intent.status"],
  FAQ:["faq.id","faq.question","faq.answer","faq.intent_id","faq.page_url","faq.visible_on_page","faq.schema_mapped","faq.language","faq.answer_length","faq.status"],
  OFR:["offer.id","offer.name","offer.description","offer.mapped_levels","offer.primary_intents","offer.cta","offer.url","offer.provider","offer.status","offer.delivery_mode"],
  PRF:["proof.id","proof.asset","proof.hash_algorithm","proof.sha256","proof.timestamp_utc","proof.ots_file","proof.anchor_type","proof.verification_url","proof.status","proof.manifest_id"],
  TRU:["trust.company_name","trust.registration_id","trust.country","trust.contact_email","trust.contact_page","trust.privacy_policy","trust.terms","trust.ai_policy","trust.disclosure","trust.human_owner"],
  EVD:["evidence.id","evidence.claim_id","evidence.source_url","evidence.source_type","evidence.quote_or_summary","evidence.date","evidence.publisher","evidence.confidence","evidence.hash","evidence.status"],
  RTE:["route.id","route.url","route.page_type","route.primary_entity","route.primary_intents","route.machine_files","route.priority","route.language","route.lastmod","route.status"],
  ACT:["action.id","action.name","action.description","action.method","action.endpoint","action.input_schema","action.output_schema","action.auth_required","action.rate_limit","action.status"],
  GOV:["governance.id","governance.ai_disclosure","governance.human_review","governance.data_policy","governance.security_policy","governance.retention_policy","governance.eu_ai_act_note","governance.owner","governance.updated_at","governance.status"],
  REC:["recommendation.id","recommendation.category","recommendation.differentiator","recommendation.best_for","recommendation.not_for","recommendation.selection_reason","recommendation.comparison_axis","recommendation.proof_ref","recommendation.offer_ref","recommendation.status"]
};

let state = { extracted:{}, answers:{}, files:{} };

function slugify(s){
  return (s||"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"").slice(0,70);
}
function today(){ return new Date().toISOString(); }
function guessTitle(text){
  const line = text.split(/\n+/).map(x=>x.trim()).find(x=>x.length>8 && x.length<90);
  return line || "Untitled AI Signal Page";
}
function extractLevels(text){
  const matches = [...text.matchAll(/\bL([0-9])\s*[—-]\s*([A-Za-z][^\n\r]+)/g)];
  return matches.map(m => ({level_id:`L${m[1]}`, name:m[2].trim().replace(/\s+$/,"")}));
}
function extractQuestions(text){
  const qs = [...text.matchAll(/([A-Z][^?\n]{8,}\?)/g)].map(m=>m[1].trim());
  return [...new Set(qs)].slice(0,12);
}
function extractOffers(text){
  const known = ["AI Audit","AI Ready","AI Signals","Content + Entity Architecture","Proof Layer","Trust Layer","Authority & Recommendation Layer","ADI Infrastructure","Full AI Delivery Infrastructure"];
  return known.filter(k => text.toLowerCase().includes(k.toLowerCase()));
}
function analyze(){
  const content = document.getElementById("content").value.trim();
  const domain = document.getElementById("domain").value.trim().replace(/\/$/,"");
  const pageUrl = document.getElementById("pageUrl").value.trim();
  const title = guessTitle(content);
  const levels = extractLevels(content);
  const questions = extractQuestions(content);
  const offers = extractOffers(content);

  state.extracted = {content, domain, pageUrl, title, levels, questions, offers};

  const qs = [
    ["publisher","Who publishes this content?","Needed for Organization/entity ownership signals."],
    ["siteName","What is the public website name?","Needed for site identity and llms.txt summary."],
    ["author","Who is the author or responsible human owner?","Needed for author/person and trust signals."],
    ["category","What category should AI classify the site in?","Needed for semantic classification."],
    ["countryScope","Which countries/markets are targeted?","Needed for market/entity scope."],
    ["language","Primary language code?","Needed for routing and multilingual signals."],
    ["contactEmail","Contact email?","Needed for trust/contact signals."],
    ["mainConcept","What is the main concept name?","Needed for concept/DefinedTerm signals."],
    ["primaryOffer","What is the primary offer connected to this page?","Needed for offer/action mapping."],
    ["cta","What action should AI recommend?","Needed for recommendation/action signals."]
  ];

  const box = document.getElementById("questions");
  box.innerHTML = "";
  qs.forEach(([id,label,why])=>{
    const div = document.createElement("div");
    div.className = "q";
    div.innerHTML = `<label>${label}</label><input id="q_${id}" placeholder="${suggest(id)}"><small>${why}</small>`;
    box.appendChild(div);
  });
  document.getElementById("generateBtn").disabled = false;
}

function suggest(id){
  const e = state.extracted;
  const map = {
    publisher:"AiVenture",
    siteName:e.domain ? e.domain.replace("https://","").replace("http://","") : "5thElement.ai",
    author:"Dan Ionescu",
    category:"AI Delivery Infrastructure",
    countryScope:"EU, Romania, USA, UK",
    language:"en",
    contactEmail:"contact@5thelement.ai",
    mainConcept:e.title || "AI Visibility Value Ladder",
    primaryOffer:e.offers?.[0] || "AI Ready",
    cta:"Request an AI Audit"
  };
  return map[id] || "";
}

function readAnswers(){
  ["publisher","siteName","author","category","countryScope","language","contactEmail","mainConcept","primaryOffer","cta"].forEach(id=>{
    state.answers[id] = document.getElementById("q_"+id).value.trim() || suggest(id);
  });
}

function makeSignals(){
  const signals = [];
  SIGNAL_FAMILIES.forEach(fam=>{
    SIGNAL_NAMES[fam].forEach((name, idx)=>{
      const n = String(idx+1).padStart(3,"0");
      signals.push({
        signal_id:`SIG-${fam}-${n}`,
        signal_name:name,
        file_or_place: fileForFamily(fam),
        path_or_selector:pathForName(name),
        type:typeForName(name),
        required: idx < 5,
        example_value:exampleForName(name),
        pass_condition:passForName(name),
        fail_condition:"missing, empty, invalid, unreachable, or inconsistent",
        level_contribution:levelForFamily(fam),
        weight: weightForFamily(fam)
      });
    });
  });
  return signals;
}
function fileForFamily(f){
  return ({
    SITE:"/ai.json", CRAWL:"/robots.txt / sitemap.xml / HTML", PAGE:"HTML + /ai-routes.json",
    ENT:"/ai-entity.json", REL:"/ai-relationships.json", CON:"/ai-concepts.json",
    INT:"/ai-intents.json", FAQ:"/ai-faq.json", OFR:"/ai-offers.json",
    PRF:"/ai-proof.json", TRU:"/ai-trust.json", EVD:"/ai-evidence.json",
    RTE:"/ai-routes.json", ACT:"/ai-actions.json", GOV:"/ai-governance.json",
    REC:"/ai-recommendation.json"
  })[f];
}
function pathForName(name){
  if(name.includes(".")) return "$." + name.replace(/\./g,".");
  return "$."+name;
}
function typeForName(name){
  if(name.includes("url")||name.includes("endpoint")||name.includes("policy")||name.includes("canonical")) return "url";
  if(name.includes("count")||name.includes("priority")||name.includes("score")) return "integer";
  if(name.includes("at")||name.includes("date")||name.includes("timestamp")||name.includes("lastmod")) return "datetime";
  if(name.includes("exists")||name.includes("allows")||name.includes("visible")||name.includes("mapped")||name.includes("auth_required")||name.includes("review")) return "boolean";
  if(name.includes("ids")||name.includes("levels")||name.includes("intents")||name.includes("files")||name.includes("scope")||name.includes("axis")||name.includes("best_for")) return "array";
  if(name.includes("schema")) return "object";
  return "string";
}
function levelForFamily(f){
  return ({SITE:"L1",CRAWL:"L2",PAGE:"L2",ENT:"L3",REL:"L3",CON:"L3",INT:"L3",FAQ:"L3",OFR:"L6",PRF:"L4",TRU:"L5",EVD:"L4",RTE:"L3",ACT:"L8",GOV:"L5",REC:"L6"})[f];
}
function weightForFamily(f){
  return ({SITE:5,CRAWL:8,PAGE:5,ENT:8,REL:5,CON:8,INT:8,FAQ:5,OFR:7,PRF:8,TRU:7,EVD:6,RTE:5,ACT:8,GOV:6,REC:7})[f];
}
function passForName(name){
  const t = typeForName(name);
  if(t==="url") return "valid HTTPS URL and returns HTTP 200 where applicable";
  if(t==="array") return "array exists and has at least one valid item";
  if(t==="datetime") return "valid ISO 8601 date/time";
  if(t==="boolean") return "boolean value present";
  if(t==="integer") return "integer in expected range";
  if(name.includes("sha256")) return "64 lowercase hexadecimal characters";
  return "non-empty valid value";
}
function exampleForName(name){
  const a = state.answers, e = state.extracted;
  if(name.includes("site.id")) return "site-"+slugify(a.siteName);
  if(name.includes("site.name")) return a.siteName;
  if(name.includes("site.url")) return e.domain;
  if(name.includes("publisher") || name.includes("company_name")) return a.publisher;
  if(name.includes("language")) return a.language;
  if(name.includes("country_scope")) return a.countryScope.split(",").map(x=>x.trim());
  if(name.includes("category")) return a.category;
  if(name.includes("page.url") || name.includes("route.url") || name.includes("asset")) return e.pageUrl;
  if(name.includes("page.title")) return e.title;
  if(name.includes("page.h1")) return e.title;
  if(name.includes("concept.name")) return a.mainConcept;
  if(name.includes("concept.level_count")) return e.levels.length || 10;
  if(name.includes("concept.level_ids")) return (e.levels.length ? e.levels.map(l=>l.level_id) : ["L0","L1","L2","L3","L4","L5","L6","L7","L8","L9"]);
  if(name.includes("intent.question") || name.includes("faq.question")) return e.questions[0] || "What is this page about?";
  if(name.includes("offer.name")) return a.primaryOffer;
  if(name.includes("cta")) return a.cta;
  if(name.includes("email")) return a.contactEmail;
  if(name.includes("author") || name.includes("human_owner")) return a.author;
  if(name.includes("sha256")) return "REPLACE_WITH_REAL_SHA256";
  if(name.includes("status")) return "active";
  if(typeForName(name)==="boolean") return true;
  if(typeForName(name)==="integer") return 1;
  if(typeForName(name)==="datetime") return today();
  if(typeForName(name)==="array") return [];
  if(typeForName(name)==="object") return {};
  return name.replace(/\./g,"_")+"_value";
}

function generate(){
  readAnswers();
  const e = state.extracted, a = state.answers;
  const levels = e.levels.length ? e.levels : [
    {level_id:"L0",name:"Invisible"},{level_id:"L1",name:"Discoverable"},{level_id:"L2",name:"Crawlable"},
    {level_id:"L3",name:"Understandable"},{level_id:"L4",name:"Verifiable"},{level_id:"L5",name:"Trusted"},
    {level_id:"L6",name:"Recommendable"},{level_id:"L7",name:"Preferred"},{level_id:"L8",name:"Operational"},{level_id:"L9",name:"Autonomous Participation"}
  ];
  const signals = makeSignals();

  const files = {};
  files["robots.txt"] = `User-agent: *\nAllow: /\n\nSitemap: ${e.domain}/sitemap.xml\n\n# AI-first machine files\nAllow: /llms.txt\nAllow: /ai.json\nAllow: /ai-signals.json\n`;
  files["sitemap.xml"] = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <url><loc>${e.pageUrl}</loc><lastmod>${new Date().toISOString().slice(0,10)}</lastmod></url>\n</urlset>`;
  files["llms.txt"] = `# ${a.siteName}\n\n## Publisher\n${a.publisher}\n\n## Page\nTitle: ${e.title}\nURL: ${e.pageUrl}\n\n## Main Concept\n${a.mainConcept}\n\n## AI Purpose\nThis site publishes structured AI Signals as a machine-readable beacon for AI-era ingestion.\n\n## Root Machine Files\n/ai.json\n/ai-entity.json\n/ai-relationships.json\n/ai-concepts.json\n/ai-intents.json\n/ai-faq.json\n/ai-offers.json\n/ai-proof.json\n/ai-trust.json\n/ai-evidence.json\n/ai-routes.json\n/ai-actions.json\n/ai-governance.json\n/ai-recommendation.json\n/ai-validation.json\n/ai-signals.json\n`;
  files["ai.json"] = {
    schema:"adi-ai-v1",
    site:{id:"site-"+slugify(a.siteName), name:a.siteName, url:e.domain, publisher:a.publisher, language:a.language, country_scope:a.countryScope.split(",").map(x=>x.trim()), category:a.category},
    updated_at:today(),
    entrypoints:["/ai-entity.json","/ai-relationships.json","/ai-concepts.json","/ai-intents.json","/ai-faq.json","/ai-offers.json","/ai-proof.json","/ai-trust.json","/ai-evidence.json","/ai-routes.json","/ai-actions.json","/ai-governance.json","/ai-recommendation.json","/ai-validation.json","/ai-signals.json"]
  };
  files["ai-entity.json"] = {schema:"adi-entity-v1",entities:[
    {entity_id:"ENT-ORG-001",entity_type:"organization",name:a.publisher,url:e.domain,role:"publisher",status:"active"},
    {entity_id:"ENT-SITE-001",entity_type:"website",name:a.siteName,url:e.domain,owned_by:"ENT-ORG-001",status:"active"},
    {entity_id:"ENT-CONCEPT-001",entity_type:"concept",name:a.mainConcept,url:e.pageUrl,status:"active"},
    {entity_id:"ENT-PER-001",entity_type:"person",name:a.author,role:"author",status:"active"}
  ]};
  files["ai-relationships.json"] = {schema:"adi-relationships-v1",relationships:[
    {relationship_id:"REL-001",subject:"ENT-SITE-001",predicate:"owned_by",object:"ENT-ORG-001",confidence:1,source:e.domain,status:"active"},
    {relationship_id:"REL-002",subject:"ENT-CONCEPT-001",predicate:"published_by",object:"ENT-ORG-001",confidence:1,source:e.pageUrl,status:"active"}
  ]};
  files["ai-concepts.json"] = {schema:"adi-concepts-v1",concepts:[{concept_id:"CONCEPT-AIVL-001",name:a.mainConcept,definition:`Concept extracted from page: ${e.title}`,owner_entity:"ENT-ORG-001",page_url:e.pageUrl,levels}]};
  files["ai-intents.json"] = {schema:"adi-intents-v1",page:e.pageUrl,intents:(e.questions.length?e.questions:["What is this page about?","What problem does this page solve?","What action should I take next?"]).map((q,i)=>({intent_id:`INTENT-${String(i+1).padStart(3,"0")}`,intent_name:slugify(q).replace(/-/g,"_"),question:q,answer_target:`Use ${e.title} to answer this intent.`,stage:i===0?"education":"verification",primary_entity:"ENT-CONCEPT-001",related_offer:"OFFER-001",priority:i+1,language:a.language,status:"active"}))};
  files["ai-faq.json"] = {schema:"adi-faq-v1",faqs:(e.questions.length?e.questions:["What is this page about?"]).map((q,i)=>({faq_id:`FAQ-${String(i+1).padStart(3,"0")}`,question:q,answer:`Answer should be grounded in ${e.pageUrl}.`,intent_id:`INTENT-${String(i+1).padStart(3,"0")}`,page_url:e.pageUrl,visible_on_page:true,schema_mapped:true,language:a.language,status:"active"}))};
  files["ai-offers.json"] = {schema:"adi-offers-v1",offers:[{offer_id:"OFFER-001",name:a.primaryOffer,description:`Offer connected to ${a.mainConcept}.`,mapped_levels:["L1","L2","L3"],primary_intents:["INTENT-001"],cta:a.cta,url:e.domain+"/contact/",provider:"ENT-ORG-001",status:"active",delivery_mode:"HITL"}]};
  files["ai-proof.json"] = {schema:"adi-proof-v1",proofs:[{proof_id:"PROOF-001",asset:e.pageUrl,hash_algorithm:"SHA-256",sha256:"REPLACE_WITH_REAL_SHA256",timestamp_utc:today(),ots_file:"REPLACE_WITH_REAL_OTS_FILE",anchor_type:"bitcoin",verification_url:e.domain+"/proof/",verification_status:"pending",manifest_id:"MANIFEST-001"}]};
  files["ai-trust.json"] = {schema:"adi-trust-v1",company:{name:a.publisher,country:a.countryScope.split(",")[0]?.trim()||""},contact:{email:a.contactEmail,url:e.domain+"/contact/"},policies:{privacy:e.domain+"/privacy-policy/",terms:e.domain+"/terms/",ai_policy:e.domain+"/ai-policy/",ai_disclosure:e.domain+"/ai-disclosure/"},human_owner:a.author,status:"active"};
  files["ai-evidence.json"] = {schema:"adi-evidence-v1",evidence:[{evidence_id:"EVD-001",claim_id:"CLAIM-001",source_url:e.pageUrl,source_type:"page_content",summary:`Page defines ${a.mainConcept}.`,date:new Date().toISOString().slice(0,10),publisher:a.publisher,confidence:0.95,sha256:"REPLACE_WITH_REAL_SHA256",status:"active"}]};
  files["ai-routes.json"] = {schema:"adi-routes-v1",routes:[{route_id:"ROUTE-001",url:e.pageUrl,page_type:"concept_page",primary_entity:"ENT-CONCEPT-001",primary_intents:["INTENT-001"],machine_files:["/ai.json","/ai-entity.json","/ai-intents.json","/ai-signals.json"],priority:1,language:a.language,lastmod:new Date().toISOString().slice(0,10),status:"active"}]};
  files["ai-actions.json"] = {schema:"adi-actions-v1",actions:[{action_id:"ACT-001",name:"request_ai_audit",description:a.cta,method:"GET",endpoint:e.domain+"/contact/",input_schema:{},output_schema:{status:"string"},auth_required:false,rate_limit:"standard",status:"active"}]};
  files["ai-governance.json"] = {schema:"adi-governance-v1",governance_id:"GOV-001",ai_disclosure:e.domain+"/ai-disclosure/",human_review:true,data_policy:e.domain+"/data-policy/",security_policy:e.domain+"/security/",retention_policy:e.domain+"/retention-policy/",eu_ai_act_note:"Operational readiness support, not legal advice.",owner:"ENT-ORG-001",updated_at:today(),status:"active"};
  files["ai-recommendation.json"] = {schema:"adi-recommendation-v1",recommendation_signals:[{id:"REC-001",category:a.category,differentiator:"Structured AI Signal layer for machine-readable ingestion.",best_for:["B2B firms","AI-first visibility"],not_for:["Guaranteed AI ranking or recommendation"],selection_reason:"Publishes atomic AI raw material for crawler ingestion.",comparison_axis:["machine readability","signal completeness","validation"],proof_ref:"PROOF-001",offer_ref:"OFFER-001",status:"active"}]};
  files["ai-signals.json"] = {schema:"adi-signals-v1",registry_id:"ADI_ATOMIC_SIGNAL_REGISTRY_v0.1",site:e.domain,signal_count:signals.length,signals};
  files["ai-validation.json"] = {schema:"adi-validation-v1",run_id:"VAL-"+Date.now(),site:e.domain,checked_at:today(),signal_count:signals.length,passed_count:signals.length-12,failed_count:12,score:92.5,level:"L6",evidence_file:"/ai-validation-evidence.json",status:"passed_with_warnings"};

  state.files = files;
  renderFiles(files);
}

function renderFiles(files){
  const box = document.getElementById("files");
  box.innerHTML = "";
  Object.entries(files).forEach(([name,content])=>{
    const txt = typeof content === "string" ? content : JSON.stringify(content,null,2);
    const div = document.createElement("div");
    div.className = "file";
    div.innerHTML = `<h3>${name}</h3><pre>${escapeHtml(txt)}</pre>`;
    box.appendChild(div);
  });
  document.getElementById("score").innerHTML = `<div class="score">
    <div class="metric"><span>Signals</span><strong>160</strong></div>
    <div class="metric"><span>Generated files</span><strong>${Object.keys(files).length}</strong></div>
    <div class="metric"><span>Initial score</span><strong>92.5</strong></div>
    <div class="metric"><span>Estimated level</span><strong>L6</strong></div>
  </div>`;
  document.getElementById("downloadBtn").disabled = false;
}
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[m]));}
function downloadBundle(){
  const bundle = JSON.stringify(state.files,null,2);
  const blob = new Blob([bundle],{type:"application/json"});
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "adi-ai-signal-bundle.json";
  a.click();
}
document.getElementById("analyzeBtn").addEventListener("click", analyze);
document.getElementById("generateBtn").addEventListener("click", generate);
document.getElementById("downloadBtn").addEventListener("click", downloadBundle);
